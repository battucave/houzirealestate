If you encounter any system error regarding 'VCRUNTIME140_1.dll', follow these steps:
1. Download the VCRUNTIME140_1.dll file
2. Place it in the path - C:\Windows\System32